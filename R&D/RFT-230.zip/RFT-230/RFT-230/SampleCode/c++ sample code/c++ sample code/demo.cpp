//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include <stdio.h>
#include <Inifiles.hpp>
#include <dos.h>

#include "demo.h"
#include "MF_API.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;

static	char	iniFile[]="ifd.ini";		//define ini file location
int lineNum=0;
int DeviceAddr = 0;
unsigned char UID[5];
int flag_TestNext = 0;

unsigned char ASCII_HEX(unsigned char *Value)
{
	unsigned char i;
	i=*Value;
	if(i >= 0x30 && i <=0x39)	i-=0x30;
	else
	{
		switch(i)
		{
		case 'a':
		case 'A':	i=0x0A;
		break;

		case 'b':
		case 'B':	i=0x0B;
		break;

		case 'c':
		case 'C':	i=0x0C;
		break;

		case 'd':
		case 'D':	i=0x0D;
		break;

		case 'e':
		case 'E':	i=0x0E;
		break;

		case 'f':
		case 'F':	i=0x0F;
		break;

		case ',':	i=0x20;
		break;
		case ' ':	i=0x20;
		break;

		default:	i=0xff;
		break;
		} //end of switch
	}//end of else
	return(i);
}

int CaulaHex(char *str,unsigned char *HexStr)
{
	int i=0;
	unsigned char buffer;

	if(*str == 0)return(-1);
	while(*str != 0x00)
	{
		if(*str == ':')break;
		if((*HexStr=ASCII_HEX(str)) > 0x10)return(-1);
		else
		{
			str++;
			if(*str == ':')	break;
			if((buffer=ASCII_HEX(str)) > 0x10)return(-1);
			*HexStr=(*HexStr<<4)+buffer;
			HexStr++;
			i++;
			str++;
			if(*str != 00)str++;
			while(*str == 0x20)str++;  //Check the space
		}
	}
	return(i);
}

void Hex2Str(unsigned char *HexStr, int len, char *str)
{
    unsigned char ch;

	for(int i=0; i<len; i++)
    {
        ch = HexStr[i] >> 4;
        if (ch > 9) ch += 0x37;
        else        ch += 0x30;
        str[3*i] = ch;

        ch = HexStr[i] & 0x0F;
        if (ch > 9) ch += 0x37;
        else        ch += 0x30;
        str[3*i + 1] = ch;

        str[3*i + 2] = ' ';
    }
    str[3* len] = 0;
}

void __fastcall TForm1::Message(String str, int MessageCode)
{
    String str1;
    char code[256];

    if (CheckBoxNop->Checked) Memo1->Lines->Add("");
    switch(MessageCode)
    {
    case 0:
        str1 = IntToStr(lineNum) + ": " + str + " (OK--0x";
        break;

    case MI_NOTAGERR:
        str1 = IntToStr(lineNum) + ": " + str + " (ERROR -->No Tag --0x";
        break;

    case MI_COLLERR:
        str1 = IntToStr(lineNum) + ": " + str + " (ERROR -->Coll error --0x";
        break;

    case MI_BITERR:
        str1 = IntToStr(lineNum) + ": " + str + " (ERROR -->Bit error --0x";
        break;

    case MI_SAKERR:
        str1 = IntToStr(lineNum) + ": " + str + " (ERROR -->SAK error --0x";
        break;

    case MI_AUTHERR:
        str1 = IntToStr(lineNum) + ": " + str + " (ERROR -->Auth error --0x";
        break;

    case MI_Value:
        str1 = IntToStr(lineNum) + ": " + str + " (ERROR -->Value error --0x";
        break;

    case MI_ACCESSERR:
        str1 = IntToStr(lineNum) + ": " + str + " (ERROR -->Access error --0x";
        break;

    case MI_ACCESSTIMEOUT:
        str1 = IntToStr(lineNum) + ": " + str + " (ERROR -->AccessTimeout error --0x";
        break;

    case MI_CommandErr:
        str1 = IntToStr(lineNum) + ": " + str + " (ERROR -->Command error --0x";
        break;

    case MI_OtherErr:
        str1 = IntToStr(lineNum) + ": " + str + " (ERROR -->Device unknown error --0x";
        break;

    case Code_RetFrameErr:
        str1 = IntToStr(lineNum) + ": " + str + " (ERROR -->Frame error --0x";
        break;

    case Code_TimeoutErr:
        str1 = IntToStr(lineNum) + ": " + str + " (ERROR -->Timeout error --0x";
        break;

    case Code_SetCommPortErr:
        str1 = IntToStr(lineNum) + ": " + str + " (ERROR -->SetCommPort error --0x";
        break;

    default:
        str1 = IntToStr(lineNum) + ": " + str + " (Other Echo --0x";
        break;
    }
    sprintf(code, "%02X)", MessageCode);
    str1 += code;
    Memo1->Lines->Add(str1);

    lineNum++;
}

//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
    : TForm(Owner)
{
    unsigned long i;
    char buff[256];
    String str;
//    int stu;

    MF_GetDLL_Ver(&buff[0]);
    str = "API Version: -->";
    str+=buff;
    Memo1->Lines->Add(str);

    TIniFile* pif = new TIniFile(ExtractFilePath(Application->ExeName) + iniFile);
    // set COM
    str=pif->ReadString("Port", "COM", "COM1");
    ComboBox_COM->Text = str;
    str=pif->ReadString("Port", "BAUD", "9600");
    ComboBox_BAUD->Text = str;


    if(MF_InitComm(ComboBox_COM->Text.c_str(),StrToInt(ComboBox_BAUD->Text.c_str()))==0)
    {
        Memo1->Lines->Add(IntToStr(lineNum)+
			": Init "+ComboBox_COM->Text+" Communication Port -( OK )");
    }
    else
    {
        Memo1->Lines->Add(IntToStr(lineNum)+": Init "+ComboBox_COM->Text+" Communication Port -( ERROR )");
    }
	lineNum++;

    WiegandConfig->Visible = pif->ReadBool("Config","Wiegand",false);
    GroupBoxSetSNR->Visible = pif->ReadBool("Config","SetSNR",false);

    Tab_Debug->Visible = pif->ReadBool("Debug","Debug",false);
    Tab_Debug->TabVisible = pif->ReadBool("Debug","Debug",false);
    delete pif;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormClose(TObject *Sender, TCloseAction &Action)
{
    TIniFile* pif = new TIniFile(ExtractFilePath(Application->ExeName) + iniFile);
    pif->WriteString("Port", "COM", ComboBox_COM->Text);
    pif->WriteString("Port", "BAUD", ComboBox_BAUD->Text);
    delete pif;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button_GetVerClick(TObject *Sender)
{
    char rsp[256];
    int stu;

    stu = MF_GetDevice_Ver(DeviceAddr, &rsp[0]);
    Message("Get BIOS Version", stu);

    String str;
    str = "    ==>  ";
    str += rsp;
    if (stu == 0)
    {
        Memo1->Lines->Add(str);
    }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button_ClearMessageClick(TObject *Sender)
{
    lineNum = 0;
    Memo1->Clear();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ComboBox_COMChange(TObject *Sender)
{
    MF_ExitComm();
    if(MF_InitComm(ComboBox_COM->Text.c_str(),StrToInt(ComboBox_BAUD->Text.c_str()))==0)
    {
        Memo1->Lines->Add(IntToStr(lineNum)+
			": Set "+ComboBox_COM->Text + " " + ComboBox_BAUD->Text + "bps -( OK )");

        TIniFile* pif = new TIniFile(ExtractFilePath(Application->ExeName) + iniFile);
        pif->WriteString("Port", "COM", ComboBox_COM->Text);
        pif->WriteString("Port", "BAUD",ComboBox_BAUD->Text);
        delete pif;
    }
    else
    {
        Memo1->Lines->Add(IntToStr(lineNum)+
			": Set "+ComboBox_COM->Text + " " + ComboBox_BAUD->Text + "bps -( ERROR )");
    }
	lineNum++;
}

//---------------------------------------------------------------------------
void __fastcall TForm1::ComboBox_AddrChange(TObject *Sender)
{
    DeviceAddr = StrToInt(ComboBox_Addr->Text.c_str());
}
//---------------------------------------------------------------------------





void __fastcall TForm1::ButtonSetDeviceBaudClick(TObject *Sender)
{
    int stu;

    stu = MF_SetDeviceBaud(DeviceAddr, ComboBoxDeviceBaud->ItemIndex);
    Message("Set Device Baudrate", stu);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ButtonSetDeviceAddrClick(TObject *Sender)
{
    int stu;

    stu = MF_SetDeviceAddr(DeviceAddr, StrToInt(EditDeviceAddr->Text.c_str()));
    Message("Set Device Address", stu);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ButtonSetDeviceSNRClick(TObject *Sender)
{
    int stu;
    
    stu = MF_SetDeviceSNR(DeviceAddr, EditDeviceSNR->Text.c_str());
    Message("Set Device SNR", stu);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button_GetAddrClick(TObject *Sender)
{
    int stu;
    unsigned char addr;
    char snr[16];

    stu = MF_GetDeviceAddr(DeviceAddr, &addr);
    if (stu==0) stu = MF_GetDeviceSNR(DeviceAddr, snr);
    Message("Get Device Address & SNR", stu);

    String str;
    if (stu == 0)
    {
        str = "    ==>  DeviceAddress: ";
        str += IntToStr(addr);
        Memo1->Lines->Add(str);

        str = "    ==>  DeviceSNR: ";
        snr[8] = 0;
        str += snr;
        Memo1->Lines->Add(str);
    }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button_GeneralCMDClick(TObject *Sender)
{
    unsigned char cmd[256], rsp[256];
    unsigned char rLen;
    int cLen;
    int stu;
    String str="";
    char code[1024];

    cLen=CaulaHex(Edit_GeneralCMD->Text.c_str(),cmd);

    if(cLen>=1)
    {
        stu = MF_GeneralCMD(DeviceAddr, &cmd[0], cLen, &rsp[0], &rLen);
        Message("Send Genaral Test Command", stu);

        if (stu == 0)
        {
            Hex2Str(&rsp[0], rLen, code);
            str = "";
            str += code;
            Edit_GenRetrun->Text = str;
        }
    }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button_ClearGenReturnClick(TObject *Sender)
{
    Edit_GenRetrun->Text = "";    
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ButtonRFonClick(TObject *Sender)
{
    int stu;

    stu = MF_SetRF_ON(DeviceAddr);
    Message("RF ON", stu);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ButtonRFoffClick(TObject *Sender)
{
    int stu;

    stu = MF_SetRF_OFF(DeviceAddr);
    Message("RF OFF", stu);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ButtonRequestAllClick(TObject *Sender)
{
    int stu;
    unsigned char CardType[2];

    stu = MF_Request(DeviceAddr, 0, CardType);
    Message("Request Card", stu);

    String str;
    char code[100];
    if (stu == 0)
    {
        str = "    ==>  CardType(Hex): ";
        sprintf(code,"%02X%02X",CardType[0],CardType[1]);
        str += code;
        Memo1->Lines->Add(str);
    }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ButtonRequestIdleClick(TObject *Sender)
{
    int stu;
    unsigned char CardType[2];

    stu = MF_Request(DeviceAddr, 1, CardType);
    Message("Request Card", stu);

    String str;
    char code[100];
    if (stu == 0)
    {
        str = "    ==>  CardType(Hex): ";
        sprintf(code,"%02X%02X",CardType[0],CardType[1]);
        str += code;
        Memo1->Lines->Add(str);
    }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ButtonAnticlollClick(TObject *Sender)
{
    int stu;

    stu = MF_Anticoll(DeviceAddr, &UID[0]);
    Message("Anticoll", stu);

    String str;
    char code[100];
    if (stu == 0)
    {
        str = "    ==>  SNR(Hex): ";
        sprintf(code,"%02X%02X%02X%02X",UID[0],UID[1],UID[2],UID[3]);
        str += code;
        Memo1->Lines->Add(str);
    }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ButtonSelectClick(TObject *Sender)
{
    int stu;

    stu = MF_Select(DeviceAddr, &UID[0]);
    Message("Select Card", stu);
/*
    String str;
    char code[100];
    if (stu == 0)
    {
        str = "    ==>  SNR(Hex): ";
        sprintf(code,"%02X%02X%02X%02X",UID[0],UID[1],UID[2],UID[3]);
        str += code;
        Memo1->Lines->Add(str);
    }
*/
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ButtonHaltClick(TObject *Sender)
{
    int stu;

    stu = MF_Halt(DeviceAddr);
    Message("Halt Card", stu);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ButtonLoadKeyClick(TObject *Sender)
{
    unsigned char Key[6];
    int stu;

    stu = CaulaHex(ComboBoxM1key->Text.c_str(),Key);
    if (stu < 6)
    {
        MessageBox(NULL,"Key Data Error!", "Input Error!",MB_ICONQUESTION);
        return;
    }

    stu = MF_LoadKey(DeviceAddr, &Key[0]);
    Message("Load Key", stu);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ButtonLoadKeyFromEEClick(TObject *Sender)
{
    unsigned char KeyType;
    unsigned char KeyNum;
    int stu;

    if (CheckBoxM1KeyAB->Checked == true) KeyType = 1;
    else KeyType = 0;
    KeyNum = StrToInt(ComboBoxM1KeyNum->Text.c_str());

    stu = MF_LoadKeyFromEE(DeviceAddr, KeyType, KeyNum);
    Message("Load From EEPROM", stu);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ButtonStoreKeyToEEClick(TObject *Sender)
{
    unsigned char Key[6];
    unsigned char KeyType;
    unsigned char KeyNum;
    int stu;

    stu = CaulaHex(ComboBoxM1key->Text.c_str(),Key);
    if (stu < 6)
    {
        MessageBox(NULL,"KEY Data Error!", "Input Error!",MB_ICONQUESTION);
        return;
    }
    if (CheckBoxM1KeyAB->Checked == true) KeyType = 1;
    else KeyType = 0;
    KeyNum = StrToInt(ComboBoxM1KeyNum->Text.c_str());

    stu = MF_StoreKeyToEE(DeviceAddr, KeyType, KeyNum, Key);
    Message("Store KEY to EEPROM", stu);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ButtonM1AuthClick(TObject *Sender)
{
    unsigned char KeyAB;
    unsigned char block;
    int stu;

    if (RadioButtonM1KeyB->Checked == true) KeyAB = 1;
    else KeyAB = 0;
    block = StrToInt(ComboBoxM1Block->Text.c_str());

    stu = MF_Authentication(DeviceAddr, KeyAB, block, UID);
    Message("Authentication KEY", stu);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ButtonM1ReadClick(TObject *Sender)
{
//MF_Read(int DeviceAddr, unsigned char block, unsigned char numbers, unsigned char *databuff);
    unsigned char block;
    unsigned char buff[64];
    int stu;

    block = StrToInt(ComboBoxM1Block->Text.c_str());

    stu = MF_Read(DeviceAddr, block, 1, buff);
    Message("Read Card", stu);

    String str;
    char code[512];
    if (stu == 0)
    {
        Hex2Str(&buff[0], 16, code);
        str = "";
        str += code;
        EditM1Data->Text = str;
    }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ButtonM1WriteClick(TObject *Sender)
{
    unsigned char block;
    unsigned char buff[64];
    int stu;

    block = StrToInt(ComboBoxM1Block->Text.c_str());
    stu = CaulaHex(EditM1Data->Text.c_str(),buff);
    if (stu < 16)
    {
        MessageBox(NULL,"Data Error", "Input Error!",MB_ICONQUESTION);
        return;
    }

    stu = MF_Write(DeviceAddr, block, 1, buff);
    Message("Write Card", stu);
/*
    String str;
    char code[512];
    if (stu == 0)
    {
        Hex2Str(&buff[0], 16, code);
        str = "";
        str += code;
        EditM1Data->Text = str;
    }
*/
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ButtonMakeValFormatClick(TObject *Sender)
{
    unsigned char block;
    unsigned char buff[64];
    long value;
    int stu;

    block = StrToInt(ComboBoxM1Block->Text.c_str());
    value = StrToInt(EditM1Value->Text.c_str());

    buff[0] = value%256;    value = value/256;
    buff[1] = value%256;    value = value/256;
    buff[2] = value%256;    value = value/256;
    buff[3] = value%256;
    for (stu=0; stu<4; stu++)   buff[4+stu] = ~buff[stu];
    for (stu=0; stu<4; stu++)   buff[8+stu] = buff[stu];
    buff[12] = block;
    buff[13] = ~block;
    buff[14] = block;
    buff[15] = ~block;

    String str;
    char code[512];

    Hex2Str(&buff[0], 16, code);
    str = "";
    str += code;
    EditM1Data->Text = str;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ButtonDecValClick(TObject *Sender)
{
    unsigned char block;
    long value;
    unsigned char buff[64];
    int stu;

    block = StrToInt(ComboBoxM1Block->Text.c_str());
    value = StrToInt(EditM1Value->Text.c_str());

    buff[0] = value%256;    value = value/256;
    buff[1] = value%256;    value = value/256;
    buff[2] = value%256;    value = value/256;
    buff[3] = value%256;
    stu = MF_Value(DeviceAddr, 0, block, buff);
    Message("Dec Value", stu);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ButtonIncValClick(TObject *Sender)
{
    unsigned char block;
    long value;
    unsigned char buff[64];
    int stu;

    block = StrToInt(ComboBoxM1Block->Text.c_str());
    value = StrToInt(EditM1Value->Text.c_str());

    buff[0] = value%256;    value = value/256;
    buff[1] = value%256;    value = value/256;
    buff[2] = value%256;    value = value/256;
    buff[3] = value%256;
    stu = MF_Value(DeviceAddr, 1, block, buff);
    Message("Inc Value", stu);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ButtonRestoreValClick(TObject *Sender)
{
    unsigned char block;
    long value;
    unsigned char buff[64];
    int stu;

    block = StrToInt(ComboBoxM1Block->Text.c_str());
    value = StrToInt(EditM1Value->Text.c_str());

    buff[0] = value%256;    value = value/256;
    buff[1] = value%256;    value = value/256;
    buff[2] = value%256;    value = value/256;
    buff[3] = value%256;
    stu = MF_Value(DeviceAddr, 2, block, buff);
    Message("Restore Value", stu);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ButtonTransferClick(TObject *Sender)
{
    unsigned char block;
    int stu;

    block = StrToInt(ComboBoxM1Block->Text.c_str());
    stu = MF_Transfer(DeviceAddr, block);
    Message("Transfer Value", stu);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ButtonTestNextClick(TObject *Sender)
{
    flag_TestNext = 1;    
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ButtonSetDeviceResetClick(TObject *Sender)
{
    int stu;

    stu = MF_DeviceReset(DeviceAddr);
    Message("Reset Value", stu);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button_BeepClick(TObject *Sender)
{
    int stu;

    stu = MF_ControlBuzzer(DeviceAddr, StrToInt(Edit_BeepTime->Text.c_str()));
    Message("Buzzer Sound", stu);
}
//---------------------------------------------------------------------------


void __fastcall TForm1::CheckBox_LED1Click(TObject *Sender)
{
    int stu;
    int led1, led2;

    led1 = 0;
    led2 = 0;
    if (CheckBox_LED1->Checked == true) led1 = 1;
    if (CheckBox_LED2->Checked == true) led2 = 1;
    stu = MF_ControlLED(DeviceAddr, led1, led2);
    Message("LED Control", stu);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::RadioButton_WiegandDisClick(TObject *Sender)
{
    CheckBoxAutoAlarm->Visible = false;
    CheckBoxHostAlarm->Visible = false;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::RadioButton_WiegandEnClick(TObject *Sender)
{
    CheckBoxAutoAlarm->Visible = true;
    CheckBoxHostAlarm->Visible = true;
}
//---------------------------------------------------------------------------


void __fastcall TForm1::Button_WiegandClick(TObject *Sender)
{
    int stu;
    int mode, alarm;

    mode = 0;
    alarm = 0;
    if (RadioButton_WiegandEn->Checked == true)
    {
        mode = 1;
        if (CheckBoxAutoAlarm->Checked == true) alarm |= 0x02;
        if (CheckBoxHostAlarm->Checked == true) alarm |= 0x01;
    }
    stu = MF_SetWiegandMode(DeviceAddr, mode, alarm);
    Message("Set Wigand Mode", stu);
}
//---------------------------------------------------------------------------


void __fastcall TForm1::Button1Click(TObject *Sender)
{
    unsigned char cmd[512], rsp[512];
    int rLen;
    int cLen;
    int i;
    unsigned char checksum;
    String str="";
    char code[1024];

    cLen=CaulaHex(Edit_GeneralCMD->Text.c_str(),cmd);

    checksum = 0;
    for (i=0; i<cLen; i++)
    {
        checksum ^= cmd[i];
    }
            Hex2Str(&checksum, 1, code);
            str = "";
            str += code;
            Edit_GenRetrun->Text = str;

}
//---------------------------------------------------------------------------

