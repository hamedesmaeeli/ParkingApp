//---------------------------------------------------------------------------

#ifndef demoH
#define demoH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
    TGroupBox *GroupBox1;
    TPageControl *TP_FunctionGroup;
    TTabSheet *Tab_Device;
    TGroupBox *GroupBox_wiegand;
    TButton *Button10;
    TCheckBox *CheckBox1;
    TCheckBox *CheckBox4;
    TCheckBox *CheckBox5;
    TGroupBox *GroupBox5;
    TCheckBox *CheckBox_LED1;
    TCheckBox *CheckBox_LED2;
    TGroupBox *GroupBox10;
    TLabel *Label14;
    TButton *Button_Beep;
    TGroupBox *GroupBox25;
    TGroupBox *GroupBox13;
    TLabel *Label35;
    TLabel *Label34;
    TComboBox *ComboBoxDeviceBaud;
    TButton *ButtonSetDeviceBaud;
    TButton *ButtonSetDeviceAddr;
    TEdit *EditDeviceAddr;
    TTabSheet *Tab_Mifare;
    TGroupBox *GroupBox8;
    TLabel *Label4;
    TLabel *Label22;
    TLabel *Label23;
    TLabel *Label37;
    TLabel *Label39;
    TComboBox *ComboBoxM1key;
    TButton *ButtonLoadKey;
    TButton *ButtonLoadKeyFromEE;
    TCheckBox *CheckBoxM1KeyAB;
    TButton *ButtonM1Auth;
    TButton *ButtonStoreKeyToEE;
    TRadioButton *RadioButtonM1KeyA;
    TRadioButton *RadioButtonM1KeyB;
    TButton *ButtonM1Read;
    TButton *ButtonM1Write;
    TEdit *EditM1Data;
    TButton *ButtonIncVal;
    TButton *ButtonDecVal;
    TButton *ButtonRestoreVal;
    TButton *ButtonTransfer;
    TEdit *EditM1Value;
    TGroupBox *GroupBox18;
    TButton *ButtonRequestAll;
    TButton *ButtonHalt;
    TButton *ButtonAnticloll;
    TButton *ButtonSelect;
    TButton *ButtonRFon;
    TButton *ButtonRFoff;
    TButton *ButtonRequestIdle;
    TTabSheet *Tab_Debug;
    TGroupBox *GroupBox6;
    TLabel *Label6;
    TLabel *Label7;
    TEdit *Edit10;
    TEdit *Edit11;
    TButton *regRead;
    TButton *regWrite;
    TGroupBox *GroupBox11;
    TLabel *Label3;
    TLabel *Label30;
    TEdit *Edit2;
    TEdit *Edit8;
    TButton *Button7;
    TButton *Button8;
    TListBox *ListBox2;
    TGroupBox *GroupBox7;
    TLabel *Label32;
    TLabel *Label33;
    TEdit *Edit_GeneralCMD;
    TButton *Button_GeneralCMD;
    TEdit *Edit_GenRetrun;
    TButton *Button_ClearGenReturn;
    TGroupBox *GroupBox14;
    TLabel *Label27;
    TLabel *Label19;
    TLabel *Label28;
    TLabel *Label29;
    TLabel *Label31;
    TComboBox *ComboBox1;
    TComboBox *ComboBox4;
    TComboBox *ComboBox_SLE_CMD;
    TComboBox *ComboBox_AT_CMD;
    TComboBox *ComboBox_Other_CMD;
    TGroupBox *GroupBox4;
    TMemo *Memo1;
    TButton *Button_ClearMessage;
    TGroupBox *GroupBox9;
    TComboBox *ComboBox_Addr;
    TComboBox *ComboBox_BAUD;
    TComboBox *ComboBox_COM;
    TLabel *Label1;
    TLabel *Label2;
    TLabel *Label12;
    TButton *ButtonMakeValFormat;
    TCheckBox *CheckBoxNop;
    TGroupBox *WiegandConfig;
    TButton *Button_Wiegand;
    TCheckBox *CheckBoxAutoAlarm;
    TCheckBox *CheckBoxHostAlarm;
    TRadioButton *RadioButton_WiegandDis;
    TRadioButton *RadioButton_WiegandEn;
    TGroupBox *GroupBoxSetSNR;
    TLabel *Label36;
    TEdit *EditDeviceSNR;
    TButton *ButtonSetDeviceSNR;
    TButton *Button_GetVer;
    TButton *Button_GetAddr;
    TButton *ButtonSetDeviceReset;
    TEdit *Edit_BeepTime;
    TComboBox *ComboBoxM1KeyNum;
    TComboBox *ComboBoxM1Block;
    TButton *Button1;
    void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
    void __fastcall Button_GetVerClick(TObject *Sender);
    void __fastcall Button_ClearMessageClick(TObject *Sender);
    void __fastcall ComboBox_COMChange(TObject *Sender);
    void __fastcall ComboBox_AddrChange(TObject *Sender);
    void __fastcall ButtonSetDeviceBaudClick(TObject *Sender);
    void __fastcall ButtonSetDeviceAddrClick(TObject *Sender);
    void __fastcall ButtonSetDeviceSNRClick(TObject *Sender);
    void __fastcall Button_GetAddrClick(TObject *Sender);
    void __fastcall Button_GeneralCMDClick(TObject *Sender);
    void __fastcall Button_ClearGenReturnClick(TObject *Sender);
    void __fastcall ButtonRequestAllClick(TObject *Sender);
    void __fastcall ButtonRFonClick(TObject *Sender);
    void __fastcall ButtonRFoffClick(TObject *Sender);
    void __fastcall ButtonRequestIdleClick(TObject *Sender);
    void __fastcall ButtonAnticlollClick(TObject *Sender);
    void __fastcall ButtonSelectClick(TObject *Sender);
    void __fastcall ButtonHaltClick(TObject *Sender);
    void __fastcall ButtonLoadKeyClick(TObject *Sender);
    void __fastcall ButtonLoadKeyFromEEClick(TObject *Sender);
    void __fastcall ButtonStoreKeyToEEClick(TObject *Sender);
    void __fastcall ButtonM1AuthClick(TObject *Sender);
    void __fastcall ButtonM1ReadClick(TObject *Sender);
    void __fastcall ButtonM1WriteClick(TObject *Sender);
    void __fastcall ButtonMakeValFormatClick(TObject *Sender);
    void __fastcall ButtonDecValClick(TObject *Sender);
    void __fastcall ButtonIncValClick(TObject *Sender);
    void __fastcall ButtonRestoreValClick(TObject *Sender);
    void __fastcall ButtonTransferClick(TObject *Sender);
    void __fastcall ButtonTestNextClick(TObject *Sender);
    void __fastcall ButtonSetDeviceResetClick(TObject *Sender);
    void __fastcall Button_BeepClick(TObject *Sender);
    void __fastcall CheckBox_LED1Click(TObject *Sender);
    void __fastcall RadioButton_WiegandDisClick(TObject *Sender);
    void __fastcall RadioButton_WiegandEnClick(TObject *Sender);
    void __fastcall Button_WiegandClick(TObject *Sender);
    void __fastcall Button1Click(TObject *Sender);
private:	// User declarations
    void __fastcall Message(String str, int MessageCode);

public:		// User declarations
    __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
