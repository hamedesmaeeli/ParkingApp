object Form1: TForm1
  Left = 223
  Top = 105
  Width = 773
  Height = 623
  Caption = 'WBE RFDemo V1.0'
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  OnClose = FormClose
  PixelsPerInch = 96
  TextHeight = 13
  object GroupBox1: TGroupBox
    Left = 7
    Top = 0
    Width = 753
    Height = 353
    TabOrder = 0
    object TP_FunctionGroup: TPageControl
      Left = 8
      Top = 12
      Width = 737
      Height = 333
      ActivePage = Tab_Device
      MultiLine = True
      TabIndex = 0
      TabOrder = 0
      object Tab_Device: TTabSheet
        Caption = 'DeviceCommand'
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -11
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ImageIndex = 4
        ParentFont = False
        object GroupBox_wiegand: TGroupBox
          Left = 8
          Top = 360
          Width = 338
          Height = 106
          Caption = 'Wiegand Option'
          TabOrder = 0
          object Button10: TButton
            Left = 176
            Top = 32
            Width = 74
            Height = 66
            Caption = 'Set'
            TabOrder = 0
          end
          object CheckBox1: TCheckBox
            Left = 40
            Top = 32
            Width = 98
            Height = 18
            Caption = 'Wiegand Enable'
            Checked = True
            State = cbChecked
            TabOrder = 1
          end
          object CheckBox4: TCheckBox
            Left = 40
            Top = 56
            Width = 98
            Height = 18
            Caption = 'Beep IntControl'
            Checked = True
            State = cbChecked
            TabOrder = 2
          end
          object CheckBox5: TCheckBox
            Left = 40
            Top = 80
            Width = 98
            Height = 18
            Caption = 'Beep ExtControl'
            Checked = True
            State = cbChecked
            TabOrder = 3
          end
        end
        object GroupBox5: TGroupBox
          Left = 280
          Top = 16
          Width = 241
          Height = 65
          Caption = 'LED Control'
          TabOrder = 1
          object CheckBox_LED1: TCheckBox
            Left = 48
            Top = 24
            Width = 57
            Height = 17
            Caption = 'LED1'
            TabOrder = 0
            OnClick = CheckBox_LED1Click
          end
          object CheckBox_LED2: TCheckBox
            Left = 112
            Top = 24
            Width = 57
            Height = 17
            Caption = 'LED2'
            TabOrder = 1
            OnClick = CheckBox_LED1Click
          end
        end
        object GroupBox10: TGroupBox
          Left = 280
          Top = 88
          Width = 241
          Height = 73
          Caption = 'Buzzer Control'
          TabOrder = 2
          object Label14: TLabel
            Left = 16
            Top = 32
            Width = 61
            Height = 13
            Caption = 'Time(*10ms):'
          end
          object Button_Beep: TButton
            Left = 160
            Top = 32
            Width = 65
            Height = 25
            Caption = 'Go'
            TabOrder = 0
            OnClick = Button_BeepClick
          end
          object Edit_BeepTime: TEdit
            Left = 88
            Top = 32
            Width = 41
            Height = 21
            TabOrder = 1
            Text = '30'
          end
        end
        object GroupBox25: TGroupBox
          Left = 8
          Top = 16
          Width = 241
          Height = 65
          Caption = 'Get Parameter '
          TabOrder = 3
          object Button_GetVer: TButton
            Left = 16
            Top = 24
            Width = 97
            Height = 25
            Caption = 'Get FirmwareVer'
            TabOrder = 0
            OnClick = Button_GetVerClick
          end
          object Button_GetAddr: TButton
            Left = 128
            Top = 24
            Width = 97
            Height = 25
            Caption = 'Get Addr&&SNR'
            TabOrder = 1
            OnClick = Button_GetAddrClick
          end
        end
        object GroupBox13: TGroupBox
          Left = 8
          Top = 88
          Width = 241
          Height = 105
          Caption = 'Config Parameter '
          TabOrder = 4
          object Label35: TLabel
            Left = 16
            Top = 48
            Width = 46
            Height = 13
            Caption = 'Baudrate:'
          end
          object Label34: TLabel
            Left = 16
            Top = 16
            Width = 41
            Height = 13
            Caption = 'Address:'
          end
          object ComboBoxDeviceBaud: TComboBox
            Left = 72
            Top = 48
            Width = 65
            Height = 21
            ItemHeight = 13
            ItemIndex = 0
            TabOrder = 0
            Text = '9600'
            Items.Strings = (
              '9600'
              '19200'
              '38400'
              '57600'
              '115200')
          end
          object ButtonSetDeviceBaud: TButton
            Left = 152
            Top = 48
            Width = 75
            Height = 25
            Caption = 'Set Baudrate'
            TabOrder = 1
            OnClick = ButtonSetDeviceBaudClick
          end
          object ButtonSetDeviceAddr: TButton
            Left = 152
            Top = 16
            Width = 75
            Height = 25
            Caption = 'Set Address'
            TabOrder = 2
            OnClick = ButtonSetDeviceAddrClick
          end
          object EditDeviceAddr: TEdit
            Left = 72
            Top = 16
            Width = 33
            Height = 21
            TabOrder = 3
            Text = '0'
          end
          object ButtonSetDeviceReset: TButton
            Left = 152
            Top = 72
            Width = 75
            Height = 25
            Caption = 'Reset Device'
            TabOrder = 4
            OnClick = ButtonSetDeviceResetClick
          end
        end
        object WiegandConfig: TGroupBox
          Left = 280
          Top = 168
          Width = 241
          Height = 105
          Caption = 'Wiegand Config'
          TabOrder = 5
          object Button_Wiegand: TButton
            Left = 160
            Top = 32
            Width = 65
            Height = 25
            Caption = 'Go'
            TabOrder = 0
            OnClick = Button_WiegandClick
          end
          object CheckBoxAutoAlarm: TCheckBox
            Left = 32
            Top = 56
            Width = 73
            Height = 17
            Caption = 'Auto Alarm'
            Checked = True
            State = cbChecked
            TabOrder = 1
            Visible = False
          end
          object CheckBoxHostAlarm: TCheckBox
            Left = 32
            Top = 72
            Width = 73
            Height = 17
            Caption = 'Host Alarm'
            Checked = True
            State = cbChecked
            TabOrder = 2
            Visible = False
          end
          object RadioButton_WiegandDis: TRadioButton
            Left = 16
            Top = 24
            Width = 121
            Height = 17
            Caption = 'Disable Wiegand'
            Checked = True
            TabOrder = 3
            TabStop = True
            OnClick = RadioButton_WiegandDisClick
          end
          object RadioButton_WiegandEn: TRadioButton
            Left = 16
            Top = 40
            Width = 105
            Height = 17
            Caption = 'Enable Wiegand'
            TabOrder = 4
            OnClick = RadioButton_WiegandEnClick
          end
        end
        object GroupBoxSetSNR: TGroupBox
          Left = 8
          Top = 200
          Width = 241
          Height = 73
          Caption = 'Set DeviceSNR'
          TabOrder = 6
          object Label36: TLabel
            Left = 24
            Top = 28
            Width = 26
            Height = 13
            Caption = 'SNR:'
          end
          object EditDeviceSNR: TEdit
            Left = 64
            Top = 28
            Width = 73
            Height = 21
            TabOrder = 0
            Text = '12345678'
          end
          object ButtonSetDeviceSNR: TButton
            Left = 152
            Top = 24
            Width = 75
            Height = 25
            Caption = 'Set SNR'
            TabOrder = 1
            OnClick = ButtonSetDeviceSNRClick
          end
        end
      end
      object Tab_Mifare: TTabSheet
        Caption = 'Mifare R/W'
        object GroupBox8: TGroupBox
          Left = 8
          Top = 96
          Width = 633
          Height = 193
          Caption = 'Mifare1 Fuction'
          Color = clBtnFace
          ParentColor = False
          TabOrder = 0
          object Label4: TLabel
            Left = 120
            Top = 24
            Width = 49
            Height = 13
            Caption = 'KEY(Hex):'
          end
          object Label22: TLabel
            Left = 120
            Top = 48
            Width = 57
            Height = 13
            Caption = 'KEY#(Dec):'
          end
          object Label23: TLabel
            Left = 296
            Top = 96
            Width = 56
            Height = 13
            Caption = 'Block(Dec):'
          end
          object Label37: TLabel
            Left = 296
            Top = 128
            Width = 51
            Height = 13
            Caption = 'Data(Hex):'
          end
          object Label39: TLabel
            Left = 296
            Top = 160
            Width = 56
            Height = 13
            Caption = 'Value(Dec):'
          end
          object ComboBoxM1key: TComboBox
            Left = 184
            Top = 24
            Width = 121
            Height = 21
            ItemHeight = 13
            TabOrder = 0
            Text = 'FF FF FF FF FF FF'
            Items.Strings = (
              'FF FF FF FF FF FF'
              'A0 A1 A2 A3 A4 A5'
              'B0 B1 B2 B3 B4 B5')
          end
          object ButtonLoadKey: TButton
            Left = 16
            Top = 24
            Width = 89
            Height = 25
            Caption = 'Load Key'
            TabOrder = 1
            OnClick = ButtonLoadKeyClick
          end
          object ButtonLoadKeyFromEE: TButton
            Left = 16
            Top = 50
            Width = 89
            Height = 25
            Caption = 'LoadKeyFromEE'
            TabOrder = 2
            OnClick = ButtonLoadKeyFromEEClick
          end
          object CheckBoxM1KeyAB: TCheckBox
            Left = 232
            Top = 52
            Width = 49
            Height = 17
            Caption = 'KeyB'
            TabOrder = 3
          end
          object ButtonM1Auth: TButton
            Left = 16
            Top = 88
            Width = 89
            Height = 25
            Caption = 'Authentication'
            TabOrder = 4
            OnClick = ButtonM1AuthClick
          end
          object ButtonStoreKeyToEE: TButton
            Left = 344
            Top = 24
            Width = 129
            Height = 41
            Caption = 'StoreKeyToEE'
            TabOrder = 5
            OnClick = ButtonStoreKeyToEEClick
          end
          object RadioButtonM1KeyA: TRadioButton
            Left = 120
            Top = 96
            Width = 57
            Height = 17
            Caption = 'KeyA'
            Checked = True
            TabOrder = 6
            TabStop = True
          end
          object RadioButtonM1KeyB: TRadioButton
            Left = 168
            Top = 96
            Width = 65
            Height = 17
            Caption = 'KeyB'
            TabOrder = 7
          end
          object ButtonM1Read: TButton
            Left = 16
            Top = 128
            Width = 62
            Height = 25
            Caption = 'Read'
            TabOrder = 8
            OnClick = ButtonM1ReadClick
          end
          object ButtonM1Write: TButton
            Left = 80
            Top = 128
            Width = 62
            Height = 25
            Caption = 'Write'
            TabOrder = 9
            OnClick = ButtonM1WriteClick
          end
          object EditM1Data: TEdit
            Left = 360
            Top = 128
            Width = 257
            Height = 21
            TabOrder = 10
            Text = '00 01 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F'
          end
          object ButtonIncVal: TButton
            Left = 80
            Top = 160
            Width = 62
            Height = 25
            Caption = 'Increment'
            TabOrder = 11
            OnClick = ButtonIncValClick
          end
          object ButtonDecVal: TButton
            Left = 16
            Top = 160
            Width = 62
            Height = 25
            Caption = 'Decrement'
            TabOrder = 12
            OnClick = ButtonDecValClick
          end
          object ButtonRestoreVal: TButton
            Left = 144
            Top = 160
            Width = 62
            Height = 25
            Caption = 'Restore'
            TabOrder = 13
            OnClick = ButtonRestoreValClick
          end
          object ButtonTransfer: TButton
            Left = 216
            Top = 160
            Width = 65
            Height = 25
            Caption = 'Transfer'
            TabOrder = 14
            OnClick = ButtonTransferClick
          end
          object EditM1Value: TEdit
            Left = 360
            Top = 160
            Width = 81
            Height = 21
            TabOrder = 15
            Text = '100'
          end
          object ButtonMakeValFormat: TButton
            Left = 504
            Top = 160
            Width = 113
            Height = 25
            Caption = 'value ==> data'
            TabOrder = 16
            OnClick = ButtonMakeValFormatClick
          end
          object ComboBoxM1KeyNum: TComboBox
            Left = 184
            Top = 48
            Width = 41
            Height = 21
            ItemHeight = 13
            TabOrder = 17
            Text = '0'
            Items.Strings = (
              '0'
              '1'
              '2'
              '3'
              '4'
              '5'
              '6'
              '7'
              '8'
              '9'
              '10'
              '11'
              '12'
              '13'
              '14'
              '15')
          end
          object ComboBoxM1Block: TComboBox
            Left = 360
            Top = 96
            Width = 49
            Height = 21
            ItemHeight = 13
            TabOrder = 18
            Text = '4'
            Items.Strings = (
              '0'
              '1'
              '2'
              '003'
              '4'
              '5'
              '6'
              '007'
              '8'
              '9'
              '10'
              '011'
              '12'
              '13'
              '14'
              '015'
              '16'
              '17'
              '18'
              '019'
              '20'
              '21'
              '22'
              '023'
              '24'
              '25'
              '26'
              '027'
              '28'
              '29'
              '30'
              '031'
              '32'
              '33'
              '34'
              '035'
              '36'
              '37'
              '38'
              '039'
              '40'
              '41'
              '42'
              '043'
              '44'
              '45'
              '46'
              '047'
              '48'
              '49'
              '50'
              '051'
              '52'
              '53'
              '54'
              '055'
              '56'
              '57'
              '58'
              '059')
          end
        end
        object GroupBox18: TGroupBox
          Left = 8
          Top = 8
          Width = 633
          Height = 81
          Caption = 'ISO14443A'
          Color = clBtnFace
          ParentColor = False
          TabOrder = 1
          object ButtonRequestAll: TButton
            Left = 24
            Top = 16
            Width = 75
            Height = 25
            Caption = 'RequestAll'
            TabOrder = 0
            OnClick = ButtonRequestAllClick
          end
          object ButtonHalt: TButton
            Left = 288
            Top = 16
            Width = 75
            Height = 25
            Caption = 'Halt'
            TabOrder = 1
            OnClick = ButtonHaltClick
          end
          object ButtonAnticloll: TButton
            Left = 112
            Top = 16
            Width = 75
            Height = 25
            Caption = 'Anticoll'
            TabOrder = 2
            OnClick = ButtonAnticlollClick
          end
          object ButtonSelect: TButton
            Left = 200
            Top = 16
            Width = 75
            Height = 25
            Caption = 'Select'
            TabOrder = 3
            OnClick = ButtonSelectClick
          end
          object ButtonRFon: TButton
            Left = 528
            Top = 16
            Width = 75
            Height = 25
            Caption = 'RF ON'
            TabOrder = 4
            OnClick = ButtonRFonClick
          end
          object ButtonRFoff: TButton
            Left = 528
            Top = 48
            Width = 75
            Height = 25
            Caption = 'RF Off'
            TabOrder = 5
            OnClick = ButtonRFoffClick
          end
          object ButtonRequestIdle: TButton
            Left = 24
            Top = 48
            Width = 75
            Height = 25
            Caption = 'RequestIdle'
            TabOrder = 6
            OnClick = ButtonRequestIdleClick
          end
        end
      end
      object Tab_Debug: TTabSheet
        Caption = 'Debug'
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -11
        Font.Name = 'MS Sans Serif'
        Font.Style = []
        ImageIndex = 2
        ParentFont = False
        ParentShowHint = False
        ShowHint = False
        object GroupBox6: TGroupBox
          Left = 16
          Top = 384
          Width = 152
          Height = 96
          Caption = 'Read/Write Register'
          TabOrder = 4
          object Label6: TLabel
            Left = 8
            Top = 24
            Width = 38
            Height = 13
            Caption = 'Address'
            Visible = False
          end
          object Label7: TLabel
            Left = 80
            Top = 24
            Width = 23
            Height = 13
            Caption = 'Data'
            Visible = False
          end
        end
        object Edit10: TEdit
          Left = 24
          Top = 424
          Width = 56
          Height = 21
          ImeName = #26234#33021'ABC'#36755#20837#27861
          MaxLength = 4
          TabOrder = 0
          Text = 'BF02'
        end
        object Edit11: TEdit
          Left = 94
          Top = 424
          Width = 58
          Height = 21
          ImeName = #26234#33021'ABC'#36755#20837#27861
          MaxLength = 2
          TabOrder = 1
          Text = '00'
        end
        object regRead: TButton
          Left = 24
          Top = 448
          Width = 56
          Height = 24
          Caption = 'Read'
          TabOrder = 2
        end
        object regWrite: TButton
          Left = 94
          Top = 448
          Width = 58
          Height = 24
          Caption = 'Write'
          TabOrder = 3
        end
        object GroupBox11: TGroupBox
          Left = 172
          Top = 384
          Width = 152
          Height = 96
          Caption = 'RC500 Register'
          TabOrder = 5
          object Label3: TLabel
            Left = 8
            Top = 24
            Width = 53
            Height = 13
            Caption = 'Add. Offset'
          end
          object Label30: TLabel
            Left = 80
            Top = 24
            Width = 27
            Height = 13
            Caption = 'Value'
          end
          object Edit2: TEdit
            Left = 8
            Top = 40
            Width = 58
            Height = 21
            TabOrder = 0
            Text = '00'
          end
          object Edit8: TEdit
            Left = 80
            Top = 40
            Width = 58
            Height = 21
            TabOrder = 1
            Text = '00'
          end
          object Button7: TButton
            Left = 8
            Top = 64
            Width = 58
            Height = 26
            Caption = 'Read'
            TabOrder = 2
          end
          object Button8: TButton
            Left = 80
            Top = 64
            Width = 58
            Height = 26
            Caption = 'Write'
            TabOrder = 3
          end
        end
        object ListBox2: TListBox
          Left = 8
          Top = 320
          Width = 324
          Height = 58
          ItemHeight = 13
          TabOrder = 6
        end
        object GroupBox7: TGroupBox
          Left = 8
          Top = 208
          Width = 569
          Height = 89
          Caption = #36890#29992#21629#20196#21457#36865#26694
          TabOrder = 7
          object Label32: TLabel
            Left = 8
            Top = 24
            Width = 36
            Height = 13
            Caption = #21629#20196#65306
          end
          object Label33: TLabel
            Left = 8
            Top = 56
            Width = 36
            Height = 13
            Caption = #36820#22238#65306
          end
          object Edit_GeneralCMD: TEdit
            Left = 40
            Top = 24
            Width = 441
            Height = 21
            TabOrder = 0
            Text = '01'
          end
          object Button_GeneralCMD: TButton
            Left = 496
            Top = 24
            Width = 65
            Height = 25
            Caption = #21457#36865#21629#20196
            TabOrder = 1
            OnClick = Button_GeneralCMDClick
          end
          object Edit_GenRetrun: TEdit
            Left = 40
            Top = 56
            Width = 441
            Height = 21
            TabOrder = 2
          end
          object Button_ClearGenReturn: TButton
            Left = 496
            Top = 56
            Width = 65
            Height = 25
            Caption = #28165#38500#36820#22238#26694
            TabOrder = 3
            OnClick = Button_ClearGenReturnClick
          end
        end
        object GroupBox14: TGroupBox
          Left = 8
          Top = 8
          Width = 569
          Height = 193
          Caption = #39044#35774#21629#20196
          TabOrder = 8
          Visible = False
          object Label27: TLabel
            Left = 16
            Top = 24
            Width = 63
            Height = 13
            Caption = #35774#22791#31867#21629#20196':'
          end
          object Label19: TLabel
            Left = 16
            Top = 56
            Width = 61
            Height = 13
            Caption = 'CPU'#21345#21629#20196':'
          end
          object Label28: TLabel
            Left = 16
            Top = 88
            Width = 71
            Height = 13
            Caption = 'SLE'#31867#21345#21629#20196':'
          end
          object Label29: TLabel
            Left = 16
            Top = 120
            Width = 65
            Height = 13
            Caption = 'AT'#31867#21345#21629#20196':'
          end
          object Label31: TLabel
            Left = 16
            Top = 152
            Width = 51
            Height = 13
            Caption = #20854#23427#21629#20196':'
          end
          object ComboBox1: TComboBox
            Left = 104
            Top = 24
            Width = 457
            Height = 21
            ItemHeight = 13
            TabOrder = 0
            Text = '02 90 00 26 07 00 04 01 00 00 00 01 B5 03'
          end
          object ComboBox4: TComboBox
            Left = 104
            Top = 56
            Width = 457
            Height = 21
            Enabled = False
            ItemHeight = 13
            TabOrder = 1
          end
          object ComboBox_SLE_CMD: TComboBox
            Left = 104
            Top = 88
            Width = 457
            Height = 21
            ItemHeight = 13
            TabOrder = 2
          end
          object ComboBox_AT_CMD: TComboBox
            Left = 104
            Top = 120
            Width = 457
            Height = 21
            ItemHeight = 13
            TabOrder = 3
          end
          object ComboBox_Other_CMD: TComboBox
            Left = 104
            Top = 152
            Width = 457
            Height = 21
            ItemHeight = 13
            TabOrder = 4
          end
        end
        object Button1: TButton
          Left = 600
          Top = 224
          Width = 75
          Height = 25
          Caption = 'Button1'
          TabOrder = 9
          OnClick = Button1Click
        end
      end
    end
  end
  object GroupBox4: TGroupBox
    Left = 7
    Top = 356
    Width = 754
    Height = 221
    Caption = 'Message && CommConfig'
    TabOrder = 1
    object Memo1: TMemo
      Left = 8
      Top = 24
      Width = 569
      Height = 185
      ImeName = #26234#33021'ABC'#36755#20837#27861
      ReadOnly = True
      ScrollBars = ssVertical
      TabOrder = 0
    end
    object Button_ClearMessage: TButton
      Left = 584
      Top = 144
      Width = 161
      Height = 38
      Caption = 'Clear Message'
      TabOrder = 1
      OnClick = Button_ClearMessageClick
    end
    object GroupBox9: TGroupBox
      Left = 584
      Top = 16
      Width = 161
      Height = 113
      Caption = 'CommConfig'
      TabOrder = 2
      object Label1: TLabel
        Left = 16
        Top = 48
        Width = 46
        Height = 13
        Caption = 'Baudrate:'
      end
      object Label2: TLabel
        Left = 16
        Top = 24
        Width = 51
        Height = 13
        Caption = 'CommPort:'
      end
      object Label12: TLabel
        Left = 16
        Top = 72
        Width = 41
        Height = 13
        Caption = 'Address:'
      end
      object ComboBox_Addr: TComboBox
        Left = 72
        Top = 76
        Width = 57
        Height = 21
        ItemHeight = 13
        TabOrder = 0
        Text = '0'
        OnChange = ComboBox_AddrChange
        Items.Strings = (
          '0'
          '1'
          '2'
          '3'
          '4'
          '5'
          '6'
          '7'
          '8'
          '9'
          '10'
          '11'
          '12'
          '13'
          '14'
          '15'
          '16'
          '17'
          '18'
          '19'
          '20'
          '')
      end
      object ComboBox_BAUD: TComboBox
        Left = 72
        Top = 48
        Width = 57
        Height = 21
        ItemHeight = 13
        TabOrder = 1
        Text = '9600'
        OnChange = ComboBox_COMChange
        Items.Strings = (
          '9600'
          '19200'
          '38400'
          '57600'
          '115200')
      end
      object ComboBox_COM: TComboBox
        Left = 72
        Top = 24
        Width = 57
        Height = 21
        ItemHeight = 13
        TabOrder = 2
        Text = 'COM1'
        OnChange = ComboBox_COMChange
        Items.Strings = (
          'COM1'
          'COM2'
          'COM3'
          'COM4'
          'COM5'
          'COM6'
          'USB')
      end
    end
    object CheckBoxNop: TCheckBox
      Left = 592
      Top = 192
      Width = 161
      Height = 17
      Caption = 'add space line after message'
      TabOrder = 3
    end
  end
end
