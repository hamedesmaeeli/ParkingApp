<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Open_Port = New System.Windows.Forms.Button
        Me.ComboBox1 = New System.Windows.Forms.ComboBox
        Me.Close_Port = New System.Windows.Forms.Button
        Me.Request = New System.Windows.Forms.Button
        Me.ListBox1 = New System.Windows.Forms.ListBox
        Me.Anticol = New System.Windows.Forms.Button
        Me.Select_Card = New System.Windows.Forms.Button
        Me.Load_Key = New System.Windows.Forms.Button
        Me.Authen = New System.Windows.Forms.Button
        Me.Read_Block = New System.Windows.Forms.Button
        Me.Button1 = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'Open_Port
        '
        Me.Open_Port.Location = New System.Drawing.Point(12, 9)
        Me.Open_Port.Name = "Open_Port"
        Me.Open_Port.Size = New System.Drawing.Size(65, 24)
        Me.Open_Port.TabIndex = 0
        Me.Open_Port.Text = "Open Port"
        Me.Open_Port.UseVisualStyleBackColor = True
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {"USB", "COM1", "COM2", "COM3", "COM4", "COM5", "COM6"})
        Me.ComboBox1.Location = New System.Drawing.Point(83, 9)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(55, 21)
        Me.ComboBox1.TabIndex = 1
        Me.ComboBox1.Text = "USB"
        '
        'Close_Port
        '
        Me.Close_Port.Enabled = False
        Me.Close_Port.Location = New System.Drawing.Point(144, 9)
        Me.Close_Port.Name = "Close_Port"
        Me.Close_Port.Size = New System.Drawing.Size(64, 24)
        Me.Close_Port.TabIndex = 2
        Me.Close_Port.Text = "Close Port"
        Me.Close_Port.UseVisualStyleBackColor = True
        '
        'Request
        '
        Me.Request.Location = New System.Drawing.Point(4, 52)
        Me.Request.Name = "Request"
        Me.Request.Size = New System.Drawing.Size(79, 24)
        Me.Request.TabIndex = 3
        Me.Request.Text = "Request"
        Me.Request.UseVisualStyleBackColor = True
        '
        'ListBox1
        '
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Location = New System.Drawing.Point(89, 52)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(254, 199)
        Me.ListBox1.TabIndex = 4
        '
        'Anticol
        '
        Me.Anticol.Location = New System.Drawing.Point(4, 82)
        Me.Anticol.Name = "Anticol"
        Me.Anticol.Size = New System.Drawing.Size(79, 24)
        Me.Anticol.TabIndex = 5
        Me.Anticol.Text = "Anticoll"
        Me.Anticol.UseVisualStyleBackColor = True
        '
        'Select_Card
        '
        Me.Select_Card.Location = New System.Drawing.Point(4, 112)
        Me.Select_Card.Name = "Select_Card"
        Me.Select_Card.Size = New System.Drawing.Size(79, 24)
        Me.Select_Card.TabIndex = 6
        Me.Select_Card.Text = "Select"
        Me.Select_Card.UseVisualStyleBackColor = True
        '
        'Load_Key
        '
        Me.Load_Key.Location = New System.Drawing.Point(4, 142)
        Me.Load_Key.Name = "Load_Key"
        Me.Load_Key.Size = New System.Drawing.Size(79, 24)
        Me.Load_Key.TabIndex = 7
        Me.Load_Key.Text = "LoadKey"
        Me.Load_Key.UseVisualStyleBackColor = True
        '
        'Authen
        '
        Me.Authen.Location = New System.Drawing.Point(4, 172)
        Me.Authen.Name = "Authen"
        Me.Authen.Size = New System.Drawing.Size(79, 24)
        Me.Authen.TabIndex = 8
        Me.Authen.Text = "Authenticate"
        Me.Authen.UseVisualStyleBackColor = True
        '
        'Read_Block
        '
        Me.Read_Block.Location = New System.Drawing.Point(4, 202)
        Me.Read_Block.Name = "Read_Block"
        Me.Read_Block.Size = New System.Drawing.Size(79, 24)
        Me.Read_Block.TabIndex = 9
        Me.Read_Block.Text = "Read"
        Me.Read_Block.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(264, 257)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(78, 22)
        Me.Button1.TabIndex = 10
        Me.Button1.Text = "Clear"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(355, 284)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Read_Block)
        Me.Controls.Add(Me.Authen)
        Me.Controls.Add(Me.Load_Key)
        Me.Controls.Add(Me.Select_Card)
        Me.Controls.Add(Me.Anticol)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.Request)
        Me.Controls.Add(Me.Close_Port)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.Open_Port)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Open_Port As System.Windows.Forms.Button
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents Close_Port As System.Windows.Forms.Button
    Friend WithEvents Request As System.Windows.Forms.Button
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents Anticol As System.Windows.Forms.Button
    Friend WithEvents Select_Card As System.Windows.Forms.Button
    Friend WithEvents Load_Key As System.Windows.Forms.Button
    Friend WithEvents Authen As System.Windows.Forms.Button
    Friend WithEvents Read_Block As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button

End Class
