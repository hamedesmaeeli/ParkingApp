Public Class Form1
    Public DLL_version(32) As Byte
    Public portN(3) As Byte
    Public Dver(32) As Byte
    Public Daddress As Byte
    Public Dsn(7) As Byte
    Public cardT(2) As Byte
    Public cardSN(3) As Byte
    Public Ckey(5) As Byte
    Public databuffer(15) As Byte
    Public value(3) As Byte
    Public Dbuffer(15) As Byte
    '  Declare Function MF_InitComm1 Lib "MF_API.dll" Alias "MF_InitComm" (ByVal portname As String, ByVal baud As Long) As Long
    ' Public Declare Function MF_InitComm Lib "MF_API.dll" (ByVal portname As String, ByVal baud As Integer) As Integer
    'Declare Function MF_ExitComm Lib "MF_API.dll" Alias "MF_ExitComm" () As Long
    ' Declare Function MF_InitComm Lib "MF_API.dll" Alias "MF_InitComm" (ByVal portname As String, ByVal baud As Long) As Long


    Private Sub Open_Port_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Open_Port.Click
        If MF_InitComm(ComboBox1.Text, 9600) = 0 Then
            Open_Port.Enabled = False
            Close_Port.Enabled = True
            ListBox1.Items.Add("Port Open")
            ListBox1.Items.Add("-------------------")
        Else
            ListBox1.Items.Add("Port Error")
            ListBox1.Items.Add("-------------------")


        End If
    End Sub

    Private Sub Close_Port_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Close_Port.Click
        If MF_ExitComm = 0 Then
            Open_Port.Enabled = True
            Close_Port.Enabled = False
        End If
    End Sub

    Private Sub Request_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Request.Click
        If MF_Request(0, 0, cardT(0)) = 0 Then
            ListBox1.Items.Add("Request OK")
            ListBox1.Items.Add("-------------------" & cardT(0) & cardT(1))
        Else
            ListBox1.Items.Add("Request Error")
            ListBox1.Items.Add("-------------------")
        End If
    End Sub

    Private Sub Anticol_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Anticol.Click
        If MF_Anticoll(0, cardSN(0)) = 0 Then
            ListBox1.Items.Add("Anticoll OK. " & "SN : " & Hex(cardSN(0)) & Hex(cardSN(1)) & Hex(cardSN(2)) & Hex(cardSN(3)))
            ListBox1.Items.Add("-------------------")
        Else
            ListBox1.Items.Add("Anticoll Error")
            ListBox1.Items.Add("-------------------")
        End If
    End Sub

    Private Sub Select_Card_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Select_Card.Click
        If MF_Select(0, cardSN(0)) = 0 Then
            ListBox1.Items.Add("Select OK")
            ListBox1.Items.Add("-------------------")
        Else
            ListBox1.Items.Add("Select Error")
            ListBox1.Items.Add("-------------------")
        End If
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Load_Key_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Load_Key.Click
        Ckey(0) = 255
        Ckey(1) = 255
        Ckey(2) = 255
        Ckey(3) = 255
        Ckey(4) = 255
        Ckey(5) = 255
        If MF_LoadKey(0, Ckey(0)) = 0 Then
            ListBox1.Items.Add("LoadKey (FF FF FF FF FF FF) OK.")
            ListBox1.Items.Add("-------------------")
        Else
            ListBox1.Items.Add("LoadKey Error")
            ListBox1.Items.Add("-------------------")
        End If
    End Sub

    Private Sub Authen_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Authen.Click
        If MF_Authentication(0, 0, 0, cardSN(0)) = 0 Then
            ListBox1.Items.Add("Authentication (Block 0) OK.")
            ListBox1.Items.Add("-------------------")
        Else
            ListBox1.Items.Add("Authentication Error")
            ListBox1.Items.Add("-------------------")
        End If
    End Sub

    Private Sub Read_Block_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Read_Block.Click
        If MF_Read(0, 0, 1, databuffer(0)) = 0 Then
            ListBox1.Items.Add("Read (Block 0) OK.")
            ListBox1.Items.Add(Hex(databuffer(0)) & " " & Hex(databuffer(1)) & " " & Hex(databuffer(2)) & " " & Hex(databuffer(3)) & " " & Hex(databuffer(4)) & " " & Hex(databuffer(5)) & " " & Hex(databuffer(6)) & " " & Hex(databuffer(7)) & " " & Hex(databuffer(8)) & " " & Hex(databuffer(9)) & " " & Hex(databuffer(10)) & " " & Hex(databuffer(11)) & " " & Hex(databuffer(12)) & " " & Hex(databuffer(13)) & " " & Hex(databuffer(14)) & " " & Hex(databuffer(15)))
            ListBox1.Items.Add("-------------------")
        Else
            ListBox1.Items.Add("Read Error")
            ListBox1.Items.Add("-------------------")
        End If
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged

    End Sub

    Private Sub clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        ListBox1.Items.Clear()
    End Sub
End Class
